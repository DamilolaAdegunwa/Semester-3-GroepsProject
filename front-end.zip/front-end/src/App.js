import React from "react";
import { Cards, CountryPicker } from "./components";
import "./App.module.css";
import { GetAllCountries } from "./api/index";
import LoginButton from "./components/Authentication/LoginButton";
import LogoutButton from "./components/Authentication/LogoutButton";

class App extends React.Component {
  state = {
    data: {},
  };
  async componentDidMount() {
    const fetchedData = await GetAllCountries();
    this.setState({ data: fetchedData });
  }
  render() {
    return (
      <div>
        <div className="container">
          <Cards data={this.state.data} />
          {/* <CountryPicker data={this.state.data} /> */}
          {/* <LoginButton />
          <LogoutButton /> */}
        </div>
      </div>

      // <BrowserRouter>
      //   <div className={AppCSS.container}>
      //     <Cards />
      //     <CountryPicker />
      //     <Chart />
      //     {/* <Link to="/secured">login</Link>
      //     <Route path="/secured" component={Secured} /> */}
      //   </div>
      // </BrowserRouter>
    );
  }
}

export default App;
