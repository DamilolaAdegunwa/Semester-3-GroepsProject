import axios from "axios";

var url = "http://localhost:8080/api/corona";

export const GetAllCountries = async () => {
  try {
    const {
      data: { countryName, confirmed, recovered },
    } = await axios.get(url);
    const modifiedData = { countryName, confirmed, recovered };

    return modifiedData;
  } catch (error) {}
};
