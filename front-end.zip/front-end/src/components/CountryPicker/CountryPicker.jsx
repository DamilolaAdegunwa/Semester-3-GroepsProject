import React from "react";

const CountryPicker = () => {
  return <h1>Pick a country</h1>;
};

export default CountryPicker;
