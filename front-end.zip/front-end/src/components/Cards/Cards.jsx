import React from "react";
import { Card, CardContent, Typography, Grid } from "@material-ui/core";
import "./Cards.module.css";
import CountUp from "react-countup";

const Cards = ({ data }) => {
  if (!data.confirmed) {
    return "Loading..";
  }

  return (
    <div className="container">
      <Grid container spacing={3} justify="center">
        <Grid item component={Card}>
          <CardContent>
            <Typography color="textSecondary" gutterBottom>
              {/* {data.countryName} */}
              Total: worldwide
            </Typography>
            <Typography variant="h5">
              Confirmed:
              <CountUp start={0} end={data.confirmed} duration={2} />
            </Typography>
            <Typography variant="h5">
              Recovered:
              <CountUp start={0} end={data.recovered} duration={2} />
            </Typography>
          </CardContent>
        </Grid>
      </Grid>
    </div>
  );
};

export default Cards;
