import React from "react";

const Chart = () => {
  return <h1>A shart</h1>;
};

export default Chart;
