/////////////// Testing tests

// Passing

describe("My First Test", () => {
  it("Does not do much!", () => {
    expect(true).to.equal(true);
  });
});

// Failing

// describe("My First Test", () => {
//   it("Does not do much!", () => {
//     expect(true).to.equal(false);
//   });
// });

/////////////// Actual tests

describe("My First Test", () => {
  it("Visits the corona counter", () => {
    cy.visit("http://localhost:3000/");

    cy.contains("worldwide");
  });
});
